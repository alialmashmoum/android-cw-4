package com.example.sw3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button H = findViewById(R.id.button2);
        Button J = findViewById(R.id.button3);
        final EditText n1 = findViewById(R.id.editTextTextPersonName4);
        TextView S = findViewById(R.id.textView);
        final EditText n2 = findViewById(R.id.editTextTextPersonName3);
        Button F = findViewById(R.id.Button);
        F.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
            int A;
                A = Integer.parseInt(n1.getText().toString());
                int D = Integer.parseInt(n2.getText().toString());
            int boo = A + D ;
                Toast.makeText(MainActivity.this, boo + "", Toast.LENGTH_SHORT).show();



            }
        });
        H .setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int A;
                A = Integer.parseInt(n1.getText().toString());
                int D = Integer.parseInt(n2.getText().toString());
                int boo = A * D ;
                Toast.makeText(MainActivity.this, boo + "", Toast.LENGTH_SHORT).show();

            }
        });
       J .setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View view) {
               int A;
               A = Integer.parseInt(n1.getText().toString());
               int D = Integer.parseInt(n2.getText().toString());
               int boo = A / D ;
               Toast.makeText(MainActivity.this, boo + "", Toast.LENGTH_SHORT).show();
           }
       });
    }
}